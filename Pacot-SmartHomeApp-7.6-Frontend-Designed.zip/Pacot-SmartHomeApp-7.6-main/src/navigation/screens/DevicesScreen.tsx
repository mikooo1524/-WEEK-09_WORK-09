import React from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useIoT } from '../../context/IoTContext';
import ErrorBanner from '../../components/ErrorBanner';

export default function DevicesScreen() {
  const { devices, devicesLoading, devicesError, deviceError, updatingDeviceIds, gatewayConnected, gatewayConnecting, toggleDevice, retryDeviceUpdate, loadDevices, connectGateway } = useIoT();
  const active = devices.filter((d) => d.status).length;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={styles.eyebrow}>CONTROL CENTER</Text>
      <Text style={styles.title}>Devices</Text>
      <Text style={styles.subtitle}>{active} of {devices.length} devices are currently active</Text>
      <View style={styles.summary}><Ionicons name="hardware-chip-outline" size={24} color="#2563eb" /><Text style={styles.summaryText}>Your connected devices</Text><Text style={styles.summaryCount}>{active}</Text></View>
      {!gatewayConnected && <ErrorBanner message="IoT Gateway is disconnected." onRetry={connectGateway} retryDisabled={gatewayConnecting} />}
      {devicesError && gatewayConnected && <ErrorBanner message={devicesError} onRetry={loadDevices} retryDisabled={devicesLoading} />}
      {deviceError && gatewayConnected && <ErrorBanner message={deviceError.message} onRetry={retryDeviceUpdate} />}
      {devicesLoading && <View style={styles.loading}><ActivityIndicator /><Text style={styles.loadingText}>Loading devices...</Text></View>}
      {devices.map((device) => {
        const updating = updatingDeviceIds.includes(device.id);
        return <View key={device.id} style={styles.deviceCard}>
          <View style={styles.iconBox}><Ionicons name={device.icon} size={26} color={device.status ? '#2563eb' : '#64748b'} /></View>
          <View style={styles.details}><Text style={styles.name}>{device.name}</Text><Text style={styles.type}>{device.type}</Text><View style={styles.statusRow}><View style={[styles.statusDot, device.status && styles.statusDotOn]} /><Text style={styles.status}>{updating ? 'Updating...' : device.status ? 'Active' : 'Off'}</Text></View></View>
          <Switch value={device.status} disabled={!gatewayConnected || updating} onValueChange={(value) => toggleDevice(device.id, value)} trackColor={{ false: '#cbd5e1', true: '#93c5fd' }} thumbColor={device.status ? '#2563eb' : '#f8fafc'} />
        </View>;
      })}
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f6f8fc' }, content: { padding: 20, paddingBottom: 35 }, eyebrow: { color: '#2563eb', fontSize: 11, fontWeight: '800', letterSpacing: 1.4 }, title: { fontSize: 30, fontWeight: '800', color: '#0f172a', marginTop: 5 }, subtitle: { color: '#64748b', marginTop: 4, marginBottom: 20 }, summary: { backgroundColor: '#eff6ff', borderRadius: 16, padding: 15, flexDirection: 'row', alignItems: 'center', marginBottom: 20 }, summaryText: { marginLeft: 10, color: '#1e3a8a', fontWeight: '700', flex: 1 }, summaryCount: { fontSize: 20, fontWeight: '800', color: '#2563eb' }, deviceCard: { backgroundColor: '#fff', borderRadius: 18, padding: 16, marginBottom: 11, flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#e2e8f0' }, iconBox: { width: 50, height: 50, borderRadius: 15, backgroundColor: '#f1f5f9', alignItems: 'center', justifyContent: 'center' }, details: { flex: 1, marginLeft: 13 }, name: { fontSize: 16, fontWeight: '800', color: '#0f172a' }, type: { color: '#64748b', fontSize: 12, marginTop: 3 }, statusRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6 }, statusDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#94a3b8', marginRight: 6 }, statusDotOn: { backgroundColor: '#22c55e' }, status: { color: '#64748b', fontSize: 11, fontWeight: '600' }, loading: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 }, loadingText: { color: '#64748b' }
});
