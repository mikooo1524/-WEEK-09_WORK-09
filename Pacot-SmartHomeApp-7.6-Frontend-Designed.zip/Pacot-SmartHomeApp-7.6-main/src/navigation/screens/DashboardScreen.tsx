import React from 'react';
import { View, Text, StyleSheet, Switch, ScrollView, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useIoT } from '../../context/IoTContext';
import ErrorBanner from '../../components/ErrorBanner';

export default function DashboardScreen() {
  const { devices, sensors, devicesLoading, sensorsLoading, devicesError, sensorsError, deviceError, updatingDeviceIds, gatewayConnected, gatewayConnecting, toggleDevice, retryDeviceUpdate, loadDevices, refreshSensors, connectGateway } = useIoT();

  const activeDevices = devices.filter((device) => device.status).length;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.topRow}>
        <View>
          <Text style={styles.eyebrow}>SMART HOME</Text>
          <Text style={styles.title}>Good evening 👋</Text>
          <Text style={styles.subtitle}>Here is your home overview</Text>
        </View>
        <View style={[styles.connectionDot, gatewayConnected && styles.connectionDotOn]}>
          <Ionicons name={gatewayConnected ? 'wifi' : 'wifi-outline'} size={20} color="#fff" />
        </View>
      </View>

      {!gatewayConnected && <ErrorBanner message="IoT Gateway is disconnected." onRetry={connectGateway} retryDisabled={gatewayConnecting} />}
      {sensorsError && gatewayConnected && <ErrorBanner message={sensorsError} onRetry={refreshSensors} retryDisabled={sensorsLoading} />}

      <View style={styles.heroCard}>
        <View>
          <Text style={styles.heroLabel}>HOME STATUS</Text>
          <Text style={styles.heroTitle}>{activeDevices} devices active</Text>
          <Text style={styles.heroText}>{gatewayConnected ? 'Everything is connected and ready.' : 'Reconnect the gateway to control devices.'}</Text>
        </View>
        <View style={styles.heroIcon}><Ionicons name="home" size={34} color="#fff" /></View>
      </View>

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Environment</Text>
        {sensorsLoading && <ActivityIndicator size="small" />}
      </View>
      <View style={styles.sensorRow}>
        <View style={styles.sensorCard}>
          <View style={styles.iconBubble}><Ionicons name="thermometer-outline" size={22} color="#2563eb" /></View>
          <Text style={styles.cardLabel}>Temperature</Text>
          <Text style={styles.sensorValue}>{sensors.temperature}°</Text>
          <Text style={styles.cardHint}>Room temperature</Text>
        </View>
        <View style={styles.sensorCard}>
          <View style={styles.iconBubble}><Ionicons name="water-outline" size={22} color="#2563eb" /></View>
          <Text style={styles.cardLabel}>Humidity</Text>
          <Text style={styles.sensorValue}>{sensors.humidity}%</Text>
          <Text style={styles.cardHint}>Relative humidity</Text>
        </View>
      </View>

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Quick Controls</Text>
        <Text style={styles.countText}>{devices.length} devices</Text>
      </View>

      {devicesError && gatewayConnected && <ErrorBanner message={devicesError} onRetry={loadDevices} retryDisabled={devicesLoading} />}
      {deviceError && gatewayConnected && <ErrorBanner message={deviceError.message} onRetry={retryDeviceUpdate} />}

      {devicesLoading && <View style={styles.loading}><ActivityIndicator /><Text style={styles.loadingText}>Loading devices...</Text></View>}

      {devices.map((device) => {
        const updating = updatingDeviceIds.includes(device.id);
        return (
          <View key={device.id} style={styles.deviceCard}>
            <View style={styles.deviceInfo}>
              <View style={[styles.deviceIcon, device.status && styles.deviceIconActive]}>
                <Ionicons name={device.icon} size={24} color={device.status ? '#2563eb' : '#64748b'} />
              </View>
              <View style={styles.deviceText}>
                <Text style={styles.deviceName}>{device.name}</Text>
                <Text style={styles.deviceType}>{device.type} · {updating ? 'Updating...' : device.status ? 'Active' : 'Off'}</Text>
              </View>
            </View>
            <Switch value={device.status} disabled={!gatewayConnected || updating} onValueChange={(value) => toggleDevice(device.id, value)} trackColor={{ false: '#cbd5e1', true: '#93c5fd' }} thumbColor={device.status ? '#2563eb' : '#f8fafc'} />
          </View>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f6f8fc' },
  content: { padding: 20, paddingBottom: 36 },
  topRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 },
  eyebrow: { fontSize: 11, fontWeight: '800', letterSpacing: 1.5, color: '#2563eb', marginBottom: 5 },
  title: { fontSize: 28, fontWeight: '800', color: '#0f172a' },
  subtitle: { fontSize: 14, color: '#64748b', marginTop: 4 },
  connectionDot: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#ef4444', alignItems: 'center', justifyContent: 'center' },
  connectionDotOn: { backgroundColor: '#2563eb' },
  heroCard: { backgroundColor: '#2563eb', borderRadius: 22, padding: 22, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  heroLabel: { color: '#dbeafe', fontSize: 11, fontWeight: '800', letterSpacing: 1.2 },
  heroTitle: { color: '#fff', fontSize: 22, fontWeight: '800', marginTop: 6 },
  heroText: { color: '#dbeafe', fontSize: 13, marginTop: 5, maxWidth: 240 },
  heroIcon: { width: 62, height: 62, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.18)', alignItems: 'center', justifyContent: 'center' },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, marginTop: 2 },
  sectionTitle: { fontSize: 19, fontWeight: '800', color: '#0f172a' },
  countText: { color: '#64748b', fontSize: 13 },
  sensorRow: { flexDirection: 'row', gap: 12, marginBottom: 25 },
  sensorCard: { flex: 1, backgroundColor: '#fff', borderRadius: 18, padding: 16, borderWidth: 1, borderColor: '#e2e8f0' },
  iconBubble: { width: 42, height: 42, borderRadius: 14, backgroundColor: '#eff6ff', alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  cardLabel: { color: '#64748b', fontSize: 12, fontWeight: '600' },
  sensorValue: { fontSize: 28, fontWeight: '800', color: '#0f172a', marginTop: 4 },
  cardHint: { color: '#94a3b8', fontSize: 11, marginTop: 2 },
  deviceCard: { backgroundColor: '#fff', borderRadius: 18, padding: 15, marginBottom: 11, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderWidth: 1, borderColor: '#e2e8f0' },
  deviceInfo: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  deviceIcon: { width: 48, height: 48, borderRadius: 15, backgroundColor: '#f1f5f9', alignItems: 'center', justifyContent: 'center' },
  deviceIconActive: { backgroundColor: '#eff6ff' },
  deviceText: { marginLeft: 12, flex: 1 },
  deviceName: { fontSize: 15, fontWeight: '800', color: '#0f172a' },
  deviceType: { fontSize: 12, color: '#64748b', marginTop: 4 },
  loading: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
  loadingText: { color: '#64748b', fontSize: 13 },
});
