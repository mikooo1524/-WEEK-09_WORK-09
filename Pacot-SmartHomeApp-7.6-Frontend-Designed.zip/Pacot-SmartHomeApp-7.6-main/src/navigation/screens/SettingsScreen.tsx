import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useIoT } from '../../context/IoTContext';

export default function SettingsScreen() {
  const [notifications, setNotifications] = useState(true); const [autoConnect, setAutoConnect] = useState(true); const [darkMode, setDarkMode] = useState(false);
  const { gatewayConnected, gatewayConnecting, connectGateway, disconnectGateway } = useIoT();
  const settings = [
    ['notifications-outline', 'Notifications', 'Receive alerts from your IoT devices', notifications, setNotifications],
    ['wifi-outline', 'Auto Connect', 'Automatically connect to the IoT gateway', autoConnect, setAutoConnect],
    ['moon-outline', 'Dark Mode', 'Use a darker application appearance', darkMode, setDarkMode],
  ] as const;
  return <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <Text style={styles.eyebrow}>PREFERENCES</Text><Text style={styles.title}>Settings</Text><Text style={styles.subtitle}>Configure your smart home experience</Text>
    <Text style={styles.section}>General</Text>
    {settings.map(([icon, name, desc, value, setter]) => <View key={name} style={styles.card}><View style={styles.info}><View style={styles.icon}><Ionicons name={icon} size={22} color="#2563eb" /></View><View style={styles.text}><Text style={styles.name}>{name}</Text><Text style={styles.desc}>{desc}</Text></View></View><Switch value={value} onValueChange={setter} trackColor={{ false: '#cbd5e1', true: '#93c5fd' }} thumbColor={value ? '#2563eb' : '#f8fafc'} /></View>)}
    <Text style={styles.section}>Connection</Text>
    <View style={styles.connection}><View style={styles.connectionTop}><View style={[styles.cloud, gatewayConnected && styles.cloudOn]}><Ionicons name={gatewayConnected ? 'cloud-done-outline' : 'cloud-offline-outline'} size={25} color={gatewayConnected ? '#2563eb' : '#64748b'} /></View><View style={{ flex: 1, marginLeft: 12 }}><Text style={styles.name}>IoT Gateway</Text><Text style={styles.desc}>{gatewayConnecting ? 'Connecting...' : gatewayConnected ? 'Connected and ready' : 'Disconnected'}</Text></View><View style={[styles.dot, gatewayConnected && styles.dotOn]} /></View>
    <TouchableOpacity style={styles.button} disabled={gatewayConnecting} onPress={gatewayConnected ? disconnectGateway : connectGateway}><Text style={styles.buttonText}>{gatewayConnected ? 'Disconnect Gateway' : 'Connect Gateway'}</Text></TouchableOpacity></View>
  </ScrollView>;
}
const styles = StyleSheet.create({ container: { flex: 1, backgroundColor: '#f6f8fc' }, content: { padding: 20, paddingBottom: 35 }, eyebrow: { color: '#2563eb', fontSize: 11, fontWeight: '800', letterSpacing: 1.4 }, title: { fontSize: 30, fontWeight: '800', color: '#0f172a', marginTop: 5 }, subtitle: { color: '#64748b', marginTop: 4, marginBottom: 24 }, section: { fontSize: 18, fontWeight: '800', color: '#0f172a', marginBottom: 12, marginTop: 2 }, card: { backgroundColor: '#fff', borderRadius: 18, padding: 15, marginBottom: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderColor: '#e2e8f0' }, info: { flexDirection: 'row', alignItems: 'center', flex: 1 }, icon: { width: 45, height: 45, borderRadius: 14, backgroundColor: '#eff6ff', alignItems: 'center', justifyContent: 'center' }, text: { flex: 1, marginLeft: 12 }, name: { fontSize: 15, fontWeight: '800', color: '#0f172a' }, desc: { fontSize: 12, color: '#64748b', marginTop: 4 }, connection: { backgroundColor: '#fff', borderRadius: 20, padding: 18, borderWidth: 1, borderColor: '#e2e8f0' }, connectionTop: { flexDirection: 'row', alignItems: 'center' }, cloud: { width: 50, height: 50, borderRadius: 15, backgroundColor: '#f1f5f9', alignItems: 'center', justifyContent: 'center' }, cloudOn: { backgroundColor: '#eff6ff' }, dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#ef4444' }, dotOn: { backgroundColor: '#22c55e' }, button: { marginTop: 17, height: 48, borderRadius: 14, backgroundColor: '#2563eb', alignItems: 'center', justifyContent: 'center' }, buttonText: { color: '#fff', fontWeight: '800' }
});
