import React from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useIoT } from '../../context/IoTContext';
import ErrorBanner from '../../components/ErrorBanner';

export default function SensorsScreen() {
  const { sensors, sensorsLoading, sensorsError, gatewayConnected, gatewayConnecting, refreshSensors, connectGateway } = useIoT();
  const cards = [
    ['thermometer-outline', 'Temperature', `${sensors.temperature} °C`, 'Current room temperature'],
    ['water-outline', 'Humidity', `${sensors.humidity} %`, 'Current relative humidity'],
    ['sunny-outline', 'Light Level', `${sensors.lightLevel} lux`, 'Current ambient light'],
  ] as const;
  return <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <Text style={styles.eyebrow}>ENVIRONMENT</Text><Text style={styles.title}>Sensors</Text><Text style={styles.subtitle}>Monitor your home environment in real time</Text>
    {!gatewayConnected && <ErrorBanner message="IoT Gateway is disconnected." onRetry={connectGateway} retryDisabled={gatewayConnecting} />}
    {sensorsError && gatewayConnected && <ErrorBanner message={sensorsError} onRetry={refreshSensors} retryDisabled={sensorsLoading} />}
    {cards.map(([icon, name, value, desc]) => <View key={name} style={styles.card}><View style={styles.top}><View style={styles.icon}><Ionicons name={icon} size={25} color="#2563eb" /></View><Text style={styles.name}>{name}</Text></View><Text style={styles.value}>{value}</Text><Text style={styles.desc}>{desc}</Text></View>)}
    <TouchableOpacity style={[styles.button, (sensorsLoading || !gatewayConnected) && styles.disabled]} onPress={refreshSensors} disabled={sensorsLoading || !gatewayConnected}>{sensorsLoading ? <ActivityIndicator color="#fff" /> : <Ionicons name="refresh-outline" size={20} color="#fff" />}<Text style={styles.buttonText}>{sensorsLoading ? 'Refreshing...' : 'Refresh Sensors'}</Text></TouchableOpacity>
  </ScrollView>;
}
const styles = StyleSheet.create({ container: { flex: 1, backgroundColor: '#f6f8fc' }, content: { padding: 20, paddingBottom: 35 }, eyebrow: { color: '#2563eb', fontSize: 11, fontWeight: '800', letterSpacing: 1.4 }, title: { fontSize: 30, fontWeight: '800', color: '#0f172a', marginTop: 5 }, subtitle: { color: '#64748b', marginTop: 4, marginBottom: 22 }, card: { backgroundColor: '#fff', borderRadius: 20, padding: 19, marginBottom: 13, borderWidth: 1, borderColor: '#e2e8f0' }, top: { flexDirection: 'row', alignItems: 'center' }, icon: { width: 48, height: 48, borderRadius: 15, backgroundColor: '#eff6ff', alignItems: 'center', justifyContent: 'center' }, name: { fontSize: 16, fontWeight: '800', color: '#0f172a', marginLeft: 12 }, value: { fontSize: 32, fontWeight: '800', color: '#0f172a', marginTop: 18 }, desc: { color: '#64748b', fontSize: 12, marginTop: 3 }, button: { height: 54, borderRadius: 16, backgroundColor: '#2563eb', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 4 }, disabled: { opacity: 0.5 }, buttonText: { color: '#fff', fontSize: 15, fontWeight: '800' } });
