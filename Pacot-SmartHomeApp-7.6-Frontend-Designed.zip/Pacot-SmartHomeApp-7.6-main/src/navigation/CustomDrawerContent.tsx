import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { DrawerContentScrollView, DrawerItemList } from '@react-navigation/drawer';
import { Ionicons } from '@expo/vector-icons';

export default function CustomDrawerContent(props: any) {
  return <DrawerContentScrollView {...props} contentContainerStyle={styles.container}>
    <View style={styles.header}>
      <View style={styles.logo}><Ionicons name="home" size={28} color="#fff" /></View>
      <Text style={styles.title}>IoT Home</Text>
      <Text style={styles.subtitle}>Smart Environment</Text>
    </View>
    <View style={styles.divider} />
    <Text style={styles.menuLabel}>MENU</Text>
    <DrawerItemList {...props} />
    <View style={styles.footer}><Ionicons name="shield-checkmark-outline" size={16} color="#64748b" /><Text style={styles.footerText}>Smart home dashboard</Text></View>
  </DrawerContentScrollView>;
}
const styles = StyleSheet.create({ container: { flex: 1, backgroundColor: '#fff' }, header: { backgroundColor: '#2563eb', paddingTop: 28, paddingBottom: 24, paddingHorizontal: 22 }, logo: { width: 54, height: 54, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.18)', alignItems: 'center', justifyContent: 'center', marginBottom: 15 }, title: { color: '#fff', fontSize: 23, fontWeight: '800' }, subtitle: { color: '#dbeafe', fontSize: 12, marginTop: 3 }, divider: { height: 1, backgroundColor: '#e2e8f0', marginTop: 15 }, menuLabel: { fontSize: 10, fontWeight: '800', color: '#94a3b8', letterSpacing: 1.3, marginHorizontal: 20, marginTop: 18, marginBottom: 4 }, footer: { marginTop: 'auto', padding: 20, flexDirection: 'row', alignItems: 'center', gap: 7 }, footerText: { color: '#64748b', fontSize: 11 }
});
